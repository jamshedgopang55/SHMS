# pdf-print
This a Nodejs multi-page HTML  to PDF converter project using puppeteerjs.

# Install Dependencies
```
npm install
```

# Start Server
```
npm start
```
#### For more details on how to setup multi-page HTML to PDF converter server read [https://www.ubercompute.com/blog/convert-multi-page-html-to-pdf-document/](https://www.ubercompute.com/blog/convert-multi-page-html-to-pdf-document/)
